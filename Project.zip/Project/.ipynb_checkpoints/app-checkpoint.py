import streamlit as st
import tensorflow as tf
import numpy as np
import joblib

st.title("Traffic Prediction (LSTM)")

@st.cache_resource
def load_all():
    model = tf.keras.models.load_model("traffic_lstm_model.keras")
    scaler = joblib.load("scaler.pkl")
    return model, scaler

model, scaler = load_all()

inputs = []
for i in range(5):
    val = st.number_input(f"Time step {i+1}", value=0.0)
    inputs.append(val)

if st.button("Predict"):
    data = np.array(inputs).reshape(-1, 1)
    data = scaler.transform(data)
    data = data.reshape((1, 5, 1))

    prediction = model.predict(data)
    prediction = scaler.inverse_transform(prediction)

    st.success(f"Predicted Traffic: {prediction[0][0]}")